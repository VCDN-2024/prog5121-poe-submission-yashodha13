/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progpoe.part3;

import javax.swing.JOptionPane; // Import JOptionPane for GUI dialogs
import java.util.ArrayList; // Import ArrayList for dynamic array storage
import java.util.List; // Import List interface for collections

public class PROGPOEPART3 {

    private String username; // Variable to store the current username
    private String password; // Variable to store the current password
    private boolean loggedIn; // Boolean flag indicating login status
    private TaskList taskList; // Instance of TaskList to manage tasks

    // Constructor to initialize the application
    public PROGPOEPART3() {
        loggedIn = false; // Start with not logged in
        taskList = new TaskList(); // Initialize an empty task list
    }

    // Method to check if username meets criteria (<= 5 characters and contains underscore)
    public boolean checkUsername(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // Method to check password complexity (at least 8 characters, contains uppercase, lowercase, and special characters)
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*[0-9].*") &&
                password.matches(".*[^A-Za-z0-9].*");
    }

    // Method to register a new user with a username and password
    public String registerUser(String username, String password) {
        if (checkUsername(username) && checkPasswordComplexity(password)) {
            this.username = username; // Set the username
            this.password = password; // Set the password
            return "Account successfully created."; // Return success message
        } else {
            return "Invalid username or password."; // Return failure message
        }
    }

    // Method to log in with a given username and password
    public boolean loginUser(String username, String password) {
        if (this.username != null && this.password != null && // Check if credentials are set
                this.username.equals(username) && this.password.equals(password)) {
            loggedIn = true; // Set logged in status to true
            return true; // Login successful
        } else {
            loggedIn = false; // Set logged in status to false
            return false; // Login failed
        }
    }

    // Method to return login status as a string
    public String returnLoginStatus() {
        return loggedIn ? "User logged in." : "User not logged in."; // Return login status message
    }

    // Method to display a welcome message to the console
    public void displayWelcomeMessage() {
        System.out.println("Welcome to EasyKanban");
    }

    // Method to add tasks to the task list
    public void addTasks() {
        if (!loggedIn) { // If not logged in, display message and return
            JOptionPane.showMessageDialog(null, "Please login first.");
            return;
        }

        int numTasks = getNumberOfTasksFromUserInput(); // Get number of tasks from user input

        for (int i = 0; i < numTasks; i++) {
            Task task = createTaskFromUserInput(); // Create task object from user input
            taskList.addTask(task); // Add task to the task list
            JOptionPane.showMessageDialog(null, "Task successfully captured"); // Show success message
            JOptionPane.showMessageDialog(null, task.printTaskDetails()); // Display task details
        }

        JOptionPane.showMessageDialog(null, "Total hours for all tasks: " + taskList.getTotalTaskHours() + " hours"); // Show total task hours
    }

    // Method to get number of tasks from user input
    private int getNumberOfTasksFromUserInput() {
        String input = JOptionPane.showInputDialog(null, "Enter the number of tasks you want to add:"); // Prompt user for input
        return Integer.parseInt(input); // Parse input as integer and return
    }

    // Method to create a task object from user input
    private Task createTaskFromUserInput() {
        String taskName = JOptionPane.showInputDialog(null, "Enter task name:"); // Prompt user for task name
        String taskDescription = getValidatedTaskDescription(); // Get validated task description
        String developerDetails = JOptionPane.showInputDialog(null, "Enter developer first and last name:"); // Prompt user for developer details
        int taskDuration = getTaskDurationFromUserInput(); // Get task duration from user input
        String taskStatus = getTaskStatusFromUserInput(); // Get task status from user input

        return new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus); // Return new Task object
    }

    // Method to get validated task description from user input
    private String getValidatedTaskDescription() {
        String taskDescription;
        do {
            taskDescription = JOptionPane.showInputDialog(null, "Enter task description:"); // Prompt user for task description
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters"); // Display error if description exceeds 50 characters
            }
        } while (taskDescription.length() > 50); // Repeat until valid description is entered
        return taskDescription; // Return validated task description
    }

    // Method to get task duration from user input
    private int getTaskDurationFromUserInput() {
        String taskDurationStr = JOptionPane.showInputDialog(null, "Enter task duration in hours:"); // Prompt user for task duration
        return Integer.parseInt(taskDurationStr); // Parse input as integer and return
    }

    // Method to get task status from user input
    private String getTaskStatusFromUserInput() {
        String[] options = {"To Do", "Doing", "Done"}; // Array of task status options
        return (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status", // Prompt user to select task status
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]); // Return selected task status
    }

    // Method to display tasks with status "Done" as a string
    public String displayTasksWithStatusDone() {
        return taskList.getTasksWithStatus("Done"); // Return tasks with status "Done" from task list
    }

    // Method to display developer with longest task in a dialog
    public void displayDeveloperWithLongestTask() {
        Task longestTask = taskList.getLongestTask(); // Get task with longest duration from task list
        if (longestTask != null) {
            JOptionPane.showMessageDialog(null, String.format("Developer with longest task: %s, Duration: %d hours",
                    longestTask.getDeveloperDetails(), longestTask.getTaskDuration())); // Show developer and duration of longest task
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found."); // Show message if no tasks found
        }
    }

    // Method to search for a task by name and display details in a dialog
    public void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the task name to search:"); // Prompt user for task name to search
        Task foundTask = taskList.findTaskByName(taskName); // Search task by name in task list
        if (foundTask != null) {
            JOptionPane.showMessageDialog(null, String.format("Task Found:\n%s", foundTask.printTaskDetails())); // Show task details if found
        } else {
            JOptionPane.showMessageDialog(null, "Task not found."); // Show message if task not found
        }
    }

    // Method to search for tasks assigned to a developer and display in a dialog
    public void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog(null, "Enter the developer name to search:"); // Prompt user for developer name to search
        String tasksByDeveloper = taskList.getTasksByDeveloper(developerName); // Get tasks assigned to developer from task list
        if (!tasksByDeveloper.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Tasks assigned to " + developerName + ":\n" + tasksByDeveloper); // Show tasks assigned to developer
        } else {
            JOptionPane.showMessageDialog(null, "No tasks assigned to " + developerName); // Show message if no tasks assigned to developer
        }
    }

    // Method to delete a task by name and display result in a dialog
    public void deleteTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the task name to delete:"); // Prompt user for task name to delete
        if (taskList.removeTaskByName(taskName)) {
            JOptionPane.showMessageDialog(null, "Task successfully deleted."); // Show success message if task deleted
        } else {
            JOptionPane.showMessageDialog(null, "Task not found."); // Show message if task not found
        }
    }

    // Method to display all task details in a dialog
    public void displayTaskReport() {
        JOptionPane.showMessageDialog(null, "Task Report:\n" + taskList.getAllTasksDetails()); // Show all task details from task list
    }

    // Getter for taskList to facilitate testing
    public TaskList getTaskList() {
        return taskList; // Return the task list
    }

    // Method to run the application
    public void run() {
        displayWelcomeMessage(); // Display welcome message

        while (true) {
            String choice = JOptionPane.showInputDialog(null, "Menu:\n1. Add tasks\n2. Show report\n3. Display tasks with status 'Done'\n4. Display developer with longest task\n5. Search task by name\n6. Search tasks by developer\n7. Delete task by name\n8. Quit\nSelect an option:"); // Prompt user for menu choice
            switch (choice) {
                case "1":
                    addTasks(); // Call addTasks method
                    break;
                case "2":
                    displayTaskReport(); // Call displayTaskReport method
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, displayTasksWithStatusDone()); // Display tasks with status 'Done'
                    break;
                case "4":
                    displayDeveloperWithLongestTask(); // Call displayDeveloperWithLongestTask method
                    break;
                case "5":
                    searchTaskByName(); // Call searchTaskByName method
                    break;
                case "6":
                    searchTasksByDeveloper(); // Call searchTasksByDeveloper method
                    break;
                case "7":
                    deleteTaskByName(); // Call deleteTaskByName method
                    break;
                case "8":
                    JOptionPane.showMessageDialog(null, "Exiting the application."); // Show exit message
                    System.exit(0); // Exit the application
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again."); // Show message for invalid option
                    break;
            }
        }
    }

    // Main method to start the application
    public static void main(String[] args) {
        PROGPOEPART3 app = new PROGPOEPART3(); // Create instance of PROGPOEPART3

        String username = JOptionPane.showInputDialog(null, "Enter username:"); // Prompt user for username
        String password = JOptionPane.showInputDialog(null, "Enter password:"); // Prompt user for password
        JOptionPane.showMessageDialog(null, app.registerUser(username, password)); // Register user and show result message

        username = JOptionPane.showInputDialog(null, "Enter username for login:"); // Prompt user for login username
        password = JOptionPane.showInputDialog(null, "Enter password for login:"); // Prompt user for login password
        if (app.loginUser(username, password)) {
            JOptionPane.showMessageDialog(null, "Login successful."); // Show success message if login successful
        } else {
            JOptionPane.showMessageDialog(null, "Login failed."); // Show failure message if login failed
        }
        System.out.println(app.returnLoginStatus()); // Print login status

        app.run(); // Run the application
    }

    // Static nested class Task representing a task
    static class Task {
        private static int taskCount = 0; // Static variable to count tasks

        private String taskName; // Task name
        private int taskNumber; // Task number
        private String taskDescription; // Task description
        private String developerDetails; // Developer details
        private int taskDuration; // Task duration
        private String taskID; // Task ID
        private String taskStatus; // Task status

        // Constructor to initialize a task object
        public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
            this.taskName = taskName; // Set task name
            this.taskDescription = taskDescription; // Set task description
            this.developerDetails = developerDetails; // Set developer details
            this.taskDuration = taskDuration; // Set task duration
            this.taskStatus = taskStatus; // Set task status
            this.taskID = generateTaskID(); // Generate task ID
            this.taskNumber = ++taskCount; // Increment task count
        }

        // Method to generate a task ID
        private String generateTaskID() {
            return "T" + taskNumber; // Return task ID
        }

        // Getter for taskName
        public String getTaskName() {
            return taskName; // Return task name
        }

        // Getter for taskID
        public String getTaskID() {
            return taskID; // Return task ID
        }

        // Getter for developerDetails
        public String getDeveloperDetails() {
            return developerDetails; // Return developer details
        }

        // Getter for taskDuration
        public int getTaskDuration() {
            return taskDuration; // Return task duration
        }

        // Getter for taskStatus
        public String getTaskStatus() {
            return taskStatus; // Return task status
        }

        // Method to print task details as a formatted string
        public String printTaskDetails() {
            return String.format("Task Name: %s\nTask ID: %s\nDeveloper: %s\nTask Duration: %d hours\nTask Status: %s",
                    taskName, taskID, developerDetails, taskDuration, taskStatus); // Return formatted task details
        }
    }

    // Static nested class TaskList representing a list of tasks
    static class TaskList {
        private List<Task> tasks; // List to store tasks

        // Constructor to initialize an empty task list
        public TaskList() {
            tasks = new ArrayList<>(); // Initialize tasks as ArrayList
        }

        // Method to add a task to the task list
        public void addTask(Task task) {
            tasks.add(task); // Add task to tasks list
        }

        // Method to get tasks with a specified status as a string
        public String getTasksWithStatus(String status) {
            StringBuilder sb = new StringBuilder(); // Initialize StringBuilder
            for (Task task : tasks) {
                if (task.getTaskStatus().equalsIgnoreCase(status)) { // Check if task status matches specified status
                    sb.append(task.printTaskDetails()).append("\n"); // Append task details to StringBuilder
                }
            }
            return sb.toString(); // Return tasks with specified status
        }

        // Method to get the task with the longest duration
        public Task getLongestTask() {
            Task longestTask = null; // Initialize longestTask as null
            int maxDuration = 0; // Initialize maxDuration as 0
            for (Task task : tasks) {
                if (task.getTaskDuration() > maxDuration) { // Compare task duration with maxDuration
                    maxDuration = task.getTaskDuration(); // Update maxDuration
                    longestTask = task; // Set longestTask to current task
                }
            }
            return longestTask; // Return task with longest duration
        }

        // Method to find a task by name
        public Task findTaskByName(String name) {
            for (Task task : tasks) {
                if (task.getTaskName().equalsIgnoreCase(name)) { // Check if task name matches specified name
                    return task; // Return task if found
                }
            }
            return null; // Return null if task not found
        }

        // Method to get tasks assigned to a specified developer as a string
        public String getTasksByDeveloper(String developer) {
            StringBuilder sb = new StringBuilder(); // Initialize StringBuilder
            for (Task task : tasks) {
                if (task.getDeveloperDetails().equalsIgnoreCase(developer)) { // Check if task developer matches specified developer
                    sb.append(task.getTaskName()).append(", "); // Append task name to StringBuilder
                }
            }
            return sb.toString(); // Return tasks assigned to specified developer
        }

        // Method to remove a task by name
        public boolean removeTaskByName(String name) {
            for (Task task : tasks) {
                if (task.getTaskName().equalsIgnoreCase(name)) { // Check if task name matches specified name
                    tasks.remove(task); // Remove task from tasks list
                    return true; // Return true if task removed
                }
            }
            return false; // Return false if task not found
        }

        // Method to get details of all tasks as a string
        public String getAllTasksDetails() {
            StringBuilder sb = new StringBuilder(); // Initialize StringBuilder
            for (Task task : tasks) {
                sb.append(task.printTaskDetails()).append("\n"); // Append task details to StringBuilder
            }
            return sb.toString(); // Return details of all tasks
        }

        // Method to get total hours of all tasks
        public int getTotalTaskHours() {
            int totalHours = 0; // Initialize totalHours as 0
            for (Task task : tasks) {
                totalHours += task.getTaskDuration(); // Add task duration to totalHours
            }
            return totalHours; // Return total hours of all tasks
        }

        // Getter for tasks to facilitate testing
        public List<Task> getTasks() {
            return tasks; // Return tasks list
        }
    }
}
/* CODE ATTRIBUTION
Java JOptionPane, geeks for geeks, 2023 accessed from: https://www.geeksforgeeks.org/java-joptionpane/
Java Booleans, w3schools, 1998 accessed from : https://www.w3schools.com/java/java_booleans.asp
Private method, geeks for geeks, 2024 accessed from : https://www.geeksforgeeks.org/how-to-call-private-method-from-another-class-in-java-with-help-of-reflection-api/ 
*/