package progpoe.part3;


// Import necessary JUnit and assertion classes
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Test class for testing the functionality of PROGPOEPART3 class
public class PROGPOEPART3TEST {

    // Instance of the application class to be tested
    private PROGPOEPART3 app;

    // Method executed before each test method to set up the application instance
    @BeforeEach
    public void setUp() {
        app = new PROGPOEPART3();
    }

    // Test case to verify account registration with valid credentials
    @Test
    public void testRegisterUser_ValidCredentials_Success() {
        String username = "valid_user";
        String password = "Password123!";
        
        // Assert that the account registration message matches the expected success message
        assertEquals("Account successfully created.", app.registerUser(username, password));
    }

    // Test case to verify account registration with an invalid username
    @Test
    public void testRegisterUser_InvalidUsername_Failure() {
        String username = "short"; // Invalid username (too short)
        String password = "Password123!";
        
        // Assert that the account registration message matches the expected failure message
        assertEquals("Invalid username or password.", app.registerUser(username, password));
    }

    // Test case to verify account registration with an invalid password
    @Test
    public void testRegisterUser_InvalidPassword_Failure() {
        String username = "valid_user";
        String password = "short1!"; // Invalid password (too short)
        
        // Assert that the account registration message matches the expected failure message
        assertEquals("Invalid username or password.", app.registerUser(username, password));
    }

    // Test case to verify successful user login with valid credentials
    @Test
    public void testLoginUser_ValidCredentials_Success() {
        String username = "valid_user";
        String password = "Password123!";
        
        // Register the user first
        app.registerUser(username, password);
        
        // Assert that login with valid credentials returns true
        assertTrue(app.loginUser(username, password));
    }

    // Test case to verify unsuccessful user login with invalid credentials
    @Test
    public void testLoginUser_InvalidCredentials_Failure() {
        String username = "valid_user";
        String password = "Password123!";
        
        // Register the user first
        app.registerUser(username, password);
        
        // Assert that login with invalid credentials returns false
        assertFalse(app.loginUser("invalid_user", password)); // Invalid username
        assertFalse(app.loginUser(username, "Invalid123!")); // Invalid password
    }

    // Test case to verify adding tasks with valid input
    @Test
    public void testAddTasks_ValidInput_Success() {
        // Simulate logging in
        app.registerUser("valid_user", "Password123!");
        app.loginUser("valid_user", "Password123!");
        
        // Add tasks
        app.addTasks();
        
        // Verify tasks were added successfully by checking the size of the task list
        assertEquals(2, app.getTaskList().getTasks().size()); // Assuming two tasks were added
    }
}
/* CODE ATTRIBUTION
Unit Testing, Kunal Nalawade, 2023 accessed from: https://www.freecodecamp.org/news/java-unit-testing/
*/